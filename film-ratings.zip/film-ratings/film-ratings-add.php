<!DOCTYPE html>
<!--	Author: Mike O'Kane
		Date:	22/12/2020
		File:	film-ratings-add.php
		Purpose:add a new rating to the film reviews file
		Ref:    Purpose:WBIP file-rating exercise using git
-->

<html>
<head>
	<title>Film Ratings - Add</title>
	<link rel ="stylesheet" type="text/css" href="film-ratings.css">
</head>
<body>

	<h1>Film Ratings - Add a New Rating</h1>

	<?php  
		
    $filmTitle = $_POST['title'];
    $numStars = strLen($_POST['rating']);

    $filmReviewsFile =fopen("film-ratings-list.txt","a");	// open the file
    
    fputs($filmReviewsFile, $filmTitle.",".$numStars."\n");	// append the film title and number of stars, separate by a comma

	fclose($filmReviewsFile);								// close the file

	?>
	<p>Thank you, your rating has been added.</p>
	<p><a href = "film-ratings.html">Return to Film Ratings Form</a></p>
</body>
</html>
